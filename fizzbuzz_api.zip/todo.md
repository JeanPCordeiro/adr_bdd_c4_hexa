- [X] Mise à jour des ADR pour le choix de déploiement Lambda/Fargate
- [X] Création des ressources Terraform pour AWS Lambda
- [X] Mise à jour du script de déploiement (deploy.sh) pour supporter Lambda/Fargate
- [X] Mise à jour du workflow GitHub Actions pour supporter Lambda/Fargate
- [X] Livraison du projet complet mis à jour

